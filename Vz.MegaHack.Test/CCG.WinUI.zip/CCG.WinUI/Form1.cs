﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml.Linq;
using Vz.MegaHack.Core;
using Vz.MegaHack.Engines;
using Vz.MegaHack.Entities;

namespace CCG.WinUI {
    public partial class Form1 : Form {
        public Form1() {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e) {
            //SqlConnection conn = new SqlConnection("Server=tcp:shameelsql.database.windows.net,1433;Database=CCG;User ID=zshameel@shameelsql;Password=shameel@77;Encrypt=True;TrustServerCertificate=False;Connection Timeout=30;");
            //conn.Open();

            PathManager.Initialize(@"D:\VzMegaHackathon\Vz.MegaHack.Web\Content\Data");

            return;

        }

        private void btnLoad_Click(object sender, EventArgs e) {
            List<LeaderBoardItem> leaderBoard = EvaluationEngine.GetLeaderBoard("001");

            textBox1.Clear();

            foreach(LeaderBoardItem item in leaderBoard) {
                textBox1.AppendText(item.ToString());
                textBox1.AppendText(Environment.NewLine);
            }
        }

        private void button1_Click(object sender, EventArgs e) {
            List<KPIItem> kpiItems = EvaluationEngine.GetSupervisorKPI("001");

            textBox1.Clear();

            foreach (KPIItem item in kpiItems) {
                textBox1.AppendText(item.ToString());
                textBox1.AppendText(Environment.NewLine);
            }
        }

        private void button2_Click(object sender, EventArgs e) {
            List<KPIItem> kpiItems = EvaluationEngine.GetCenterKPI("001");

            textBox1.Clear();

            foreach (KPIItem item in kpiItems) {
                textBox1.AppendText(item.ToString());
                textBox1.AppendText(Environment.NewLine);
            }
        }

        private void button3_Click(object sender, EventArgs e) {
            var items = EvaluationEngine.GetHeatMap("001");

            textBox1.Clear();

            foreach (var item in items) {
                foreach(var element in item) {
                    textBox1.AppendText(string.Format("{0}={1}; ", element.Key, element.Value));
                }
                textBox1.AppendText(Environment.NewLine);
            }
        }

        private void button6_Click(object sender, EventArgs e) {
            List<AgentKPIScore> items = EvaluationEngine.GetAgentDashboard("001");

            textBox1.Clear();

            foreach (AgentKPIScore item in items) {
                textBox1.AppendText(item.ToString());
                textBox1.AppendText(Environment.NewLine);
            }
        }

        private void button4_Click(object sender, EventArgs e) {
            string fileName = Path.Combine(PathManager.DataPath, "AgentInfo.xml");
            string namesFile = Path.Combine(PathManager.DataPath, "Names.txt");
            string[] names = File.ReadAllLines(namesFile);

            XDocument doc = XDocument.Load(fileName);

            var items = doc.Root.Elements("Agent");
            Random rnd = new Random(Int32.MaxValue);
            Random rnd2 = new Random(Int32.MaxValue/4);

            int nameIndex = 0;
            int imageIndex = 0;

            foreach (var item in items) {
                item.Attribute("name").Value = names[nameIndex].Trim();
                item.Attribute("points").Value = rnd.Next(0, 1000).ToString();

                if (nameIndex < 40) {
                    imageIndex = rnd2.Next(1, 6);
                } else {
                    imageIndex = rnd2.Next(7, 10);
                }

                item.Attribute("photoFileName").Value = string.Format("agent{0}.jpg", imageIndex);
                nameIndex++;
            }

            doc.Save(fileName);
        }

        private void button5_Click(object sender, EventArgs e) {
            string fileName = Path.Combine(PathManager.DataPath, "AgentKPI.xml");
            if (File.Exists(fileName)) {
                File.Delete(fileName);
            }

            XDocument doc = new XDocument(new XElement("Agents"));

            Random rndKpiValue = new Random(Int32.MaxValue);
            Random rndDate = new Random(4236486);
            Random rndTraining = new Random(303434);
            Random rndAward = new Random(72104630);
            DateTime refDate = new DateTime(2015, 1, 1);

            for (int agent = 1; agent <= 80; agent++) {
                for (int kpi = 1; kpi <= 18; kpi++) {
                    XElement element = new XElement("Agent");
                    element.SetAttributeValue("id", agent.ToString("D3"));
                    element.SetAttributeValue("kpiId", kpi.ToString("D3"));
                    element.SetAttributeValue("date", refDate.AddDays(rndDate.Next(0,300)).ToString("yyyy/MM/dd"));
                    element.SetAttributeValue("kpiValue", rndKpiValue.Next(0, 100).ToString());

                    bool hadTraining = ((rndTraining.Next(0, 1000)) % 2 == 0);
                    element.SetAttributeValue("hadTraining", hadTraining.ToString());

                    bool isAwarded = ((rndAward.Next(0, 1000)) % 2 == 0);
                    element.SetAttributeValue("isAwarded", isAwarded.ToString());

                    string description = string.Empty;
                    if (hadTraining) {
                        description += string.Format("Training {0} attended. ", rndTraining.Next(1,100));
                    }
                    if (isAwarded) {
                        description += string.Format("Award {0} presented.", rndAward.Next(1, 100));
                    }

                    element.SetAttributeValue("description", description);

                    doc.Root.Add(element);
                }
            }
            
            doc.Save(fileName);
        }

    }
}
